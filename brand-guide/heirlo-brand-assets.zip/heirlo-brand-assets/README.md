# Heirlo Brand Assets

Version 3.6 · May 2026

This bundle contains all brand-approved Heirlo visual assets in SVG (vector source) and JPG (raster) formats.

## Contents

### Marks
- `app-icon.svg` — Production iOS app icon
- `dandelion-{geometric,refined,engraved}.svg` — Three mark styles, light surface
- `dandelion-{geometric,refined,engraved}-light.svg` — Three mark styles, dark surface
- `dandelion-refined-brass.svg` — Refined mark, brass on cream
- `seed-{geometric,refined,engraved}.svg` — Smaller seed reading
- `seed-refined-brass.svg` — Brass-on-cream seed variant

### UI
- `icon-seed-{simple,line,filled}.svg` — 24×24 UI icons (light surface)
- `icon-seed-{line,filled}-light.svg` — Dark surface variants
- `favicon-{16,32}.svg` — Browser tab icons

### Identity
- `social-avatar-dark.svg` — Social profile master (1080×1080)
- `email-signature.svg` — Light surface email signature template
- `email-signature-dark.svg` — Dark surface email signature template
- `letterhead-dark.svg` — Dark letterhead template

### Patterns
- `scatter-tile{,-dark}.svg` — Seamless 240×240 tile
- `scatter-loose{,-dark}.svg` — 1600×900 atmospheric scatter

### JPG renders
All SVGs above also rendered as high-resolution JPGs in `/jpg/`.
JPG wordmark/template text uses Lora as a Fraunces stand-in (see brand guide note).

## Brand guide
Full guide: https://heirlo.app/brand-guide

## Questions
hello@heirlo.app
